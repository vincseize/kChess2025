<?php
// content.php - Layout Desktop avec menu à gauche et statut intégré
require_once __DIR__ . '/config-loader.php';
$config = loadGameConfig();

$lang = $config['current_lang'];
$translations = $config['lang'][$lang];
?>

<main class="container-fluid py-3">
    <div class="row g-3">
        <div class="col-xxl-2 col-xl-3 col-lg-3 col-md-4 col-12">
            <div class="card shadow-sm border-0 h-100">
                <div class="card-body p-3">
                    <div class="d-grid gap-2">
                        <a href="index.php" class="btn btn-primary btn-sm">
                            <i class="bi bi-house-door me-1"></i> <?php echo htmlspecialchars($translations['accueil']); ?>
                        </a>
                        
                        <button type="button" class="btn btn-success btn-sm new-game-btn" id="newGame">
                            <i class="bi bi-plus-circle me-1"></i> <?php echo htmlspecialchars($translations['new_game']); ?>
                        </button>

                        <button type="button" class="btn btn-outline-success btn-sm" id="playAgain">
                            <i class="bi bi-arrow-clockwise me-1"></i> <?php echo htmlspecialchars($translations['play_again'] ?? 'Rejouer'); ?>
                        </button>
                        
                        <button class="btn btn-outline-dark btn-sm flip-board-btn" id="flipBoardDesktop">
                            <i class="bi bi-arrow-repeat me-1"></i> <?php echo htmlspecialchars($translations['flip_board']); ?>
                        </button>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xxl-8 col-xl-6 col-lg-6 col-md-8 col-12">
            <div class="chess-container bg-light rounded-3 p-2 h-100 position-relative shadow-sm border">
                <div class="position-absolute top-0 start-0 m-2" style="z-index: 10;">
                    <span id="topPlayerLabel" class="badge bg-dark text-white p-2 shadow-sm border border-secondary"></span>
                </div>
                
                <div class="position-absolute bottom-0 start-0 m-2" style="z-index: 10;">
                    <span id="bottomPlayerLabel" class="badge bg-white text-dark border border-dark p-2 shadow-sm"></span>
                </div>

                <div class="chess-board-container mx-auto w-100 h-100 d-flex align-items-center justify-content-center">
                    <div id="chessBoard" class="chess-board"></div>
                </div>
            </div>
        </div>

        <div class="col-xxl-2 col-xl-3 col-lg-3 col-12">
            <div class="game-info-container h-100 d-flex flex-column">
                
                <div class="card mb-3 shadow-sm border-primary overflow-hidden">
                    <div id="currentPlayer" class="small fw-bold p-2 bg-light border-bottom text-center text-uppercase" style="letter-spacing: 1px;">
                        <?php echo htmlspecialchars($translations['traitAuBlancs']); ?>
                    </div>
                    <div class="row g-0 align-items-center bg-white text-center">
                        <div class="col-6 p-2 border-end">
                            <span class="text-muted d-block mb-1" style="font-size:0.65rem; font-weight: 800;">BLANCS</span>
                            <div id="whiteTime" class="fw-bold fs-5 text-primary font-monospace">00:00</div>
                            <div id="whiteInfo" class="text-success fw-bold" style="font-size:0.6rem; min-height: 12px;"></div>
                        </div>
                        <div class="col-6 p-2">
                            <span class="text-muted d-block mb-1" style="font-size:0.65rem; font-weight: 800;">NOIRS</span>
                            <div id="blackTime" class="fw-bold fs-5 text-danger font-monospace">00:00</div>
                            <div id="blackInfo" class="text-success fw-bold" style="font-size:0.6rem; min-height: 12px;"></div>
                        </div>
                    </div>
                </div>

                <div class="card flex-grow-1 shadow-sm overflow-hidden">
                    <div class="card-header bg-warning text-dark py-2 d-flex justify-content-between align-items-center">
                        <h4 class="h6 mb-0 fw-bold"><i class="bi bi-clock-history me-1"></i> <?php echo htmlspecialchars($translations['moves_title']); ?></h4>
                        <div class="btn-group">
                            <button class="btn btn-xs btn-dark py-0 px-2" style="font-size:0.7rem" id="copyPGN">PGN</button>
                            <button class="btn btn-xs btn-secondary py-0 px-2" style="font-size:0.7rem" id="copyFEN">FEN</button>
                        </div>
                    </div>
                    <div class="card-body p-0">
                        <div id="moveHistory" class="move-history" style="max-height: 400px; overflow-y: auto; font-family: monospace; font-size: 0.85rem;">
                            <div class="text-center text-muted small p-3"><?php echo htmlspecialchars($translations['no_moves_played']); ?></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>

<footer class="bg-dark py-3 mt-auto">
    <div class="container text-center text-white-50">
        <small><?php echo htmlspecialchars($translations['app_name']); ?> v<?php echo htmlspecialchars($config['version']); ?> | <?php echo date('Y'); ?></small>
    </div>
</footer>

<script>
window.translations = <?php echo json_encode($translations, JSON_UNESCAPED_UNICODE); ?>;
window.getTranslation = (key, def = '') => window.translations[key] || def;

// Parseur sécurisé pour l'incrément (HH:MM:SS -> secondes)
function parseIncrement(incStr) {
    if (!incStr || typeof incStr !== 'string') return 0;
    const parts = incStr.split(':');
    return parseInt(parts[parts.length - 1]) || 0;
}

// Mise à jour des noms des joueurs
window.updatePlayerLabels = function(isBotGame = false, botColor = null, botLevel = null) {
    const top = document.getElementById('topPlayerLabel');
    const bottom = document.getElementById('bottomPlayerLabel');
    if (!top || !bottom) return;

    const human = window.getTranslation('human_player', 'Humain');
    const white = window.getTranslation('white_player', 'Blancs');
    const black = window.getTranslation('black_player', 'Noirs');
    let botName = window.getTranslation('computer_player', 'Bot');
    
    if (botLevel && window.translations.bots) {
        const botData = window.translations.bots['bot_' + botLevel];
        if (botData) botName = botData.title;
    }

    if (isBotGame && botColor === 'black') {
        top.innerHTML = `<i class="bi bi-cpu me-1"></i> ${botName} (${black})`;
        bottom.innerHTML = `<i class="bi bi-person me-1"></i> ${human} (${white})`;
    } else if (isBotGame && botColor === 'white') {
        top.innerHTML = `<i class="bi bi-person me-1"></i> ${human} (${black})`;
        bottom.innerHTML = `<i class="bi bi-cpu me-1"></i> ${botName} (${white})`;
    } else {
        top.innerHTML = `<i class="bi bi-person me-1"></i> ${human} (${black})`;
        bottom.innerHTML = `<i class="bi bi-person me-1"></i> ${human} (${white})`;
    }
};

window.updateGameStatus = (currentPlayer) => {
    const el = document.getElementById('currentPlayer');
    if (el) el.textContent = window.getTranslation(currentPlayer === 'white' ? 'traitAuBlancs' : 'traitAuxNoirs');
};

window.updateTimeDisplay = (w, b) => {
    const f = (s) => {
        const totalSec = Math.max(0, Math.floor(s));
        const min = Math.floor(totalSec / 60).toString().padStart(2, '0');
        const sec = (totalSec % 60).toString().padStart(2, '0');
        return `${min}:${sec}`;
    };
    if (document.getElementById('whiteTime')) document.getElementById('whiteTime').textContent = f(w);
    if (document.getElementById('blackTime')) document.getElementById('blackTime').textContent = f(b);
};

// Affichage de l'incrément
window.displayGameSettings = function(level) {
    const botData = window.translations.bots ? window.translations.bots['bot_' + level] : null;
    if (botData && botData.increment) {
        const incSec = parseIncrement(botData.increment);
        const text = incSec > 0 ? `<i class="bi bi-plus"></i>${incSec}s inc.` : "";
        document.getElementById('whiteInfo').innerHTML = text;
        document.getElementById('blackInfo').innerHTML = text;
    }
};

document.addEventListener('DOMContentLoaded', function() {
    
    // NOUVELLE PARTIE
    document.querySelectorAll('.new-game-btn').forEach(btn => {
        btn.addEventListener('click', function(e) {
            e.preventDefault();
            if (window.localStorage) localStorage.clear();
            window.location.replace('index.php?new');
        }); 
    });

    // REJOUER
    const playAgainBtn = document.getElementById('playAgain');
    if (playAgainBtn) {
        playAgainBtn.addEventListener('click', (e) => {
            e.preventDefault();
            window.location.reload();
        });
    }

    // FLIP BOARD
    document.querySelectorAll('.flip-board-btn').forEach(btn => {
        btn.addEventListener('click', (e) => {
            e.preventDefault();
            if (window.chessGame?.flipBoard) window.chessGame.flipBoard();
        });
    });

    // Initialisation
    const params = new URLSearchParams(window.location.search);
    const level = params.get('level');
    if (level) window.displayGameSettings(level);

    if (params.get('mode') === 'bot') {
        const bCol = (params.get('color') === 'white') ? 'black' : 'white';
        window.updatePlayerLabels(true, bCol, level);
    } else {
        window.updatePlayerLabels(false);
    }
});
</script>

<style>
.btn-xs { padding: 1px 5px; font-size: 0.75rem; }
.move-history::-webkit-scrollbar { width: 4px; }
.move-history::-webkit-scrollbar-thumb { background: #ccc; border-radius: 10px; }
.font-monospace { font-family: 'Courier New', Courier, monospace !important; }
#whiteTime, #blackTime { line-height: 1.2; letter-spacing: -0.5px; }
#whiteInfo, #blackInfo { font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px; }
</style>