<?php
// footer.php
include __DIR__ . '/engine-scripts.php'; 
?>
</body>
</html>